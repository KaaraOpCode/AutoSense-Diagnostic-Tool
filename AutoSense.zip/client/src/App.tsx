import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/hooks/use-theme";
import Header from "@/components/Header";
import Hero from "@/components/Hero";
import Dashboard from "@/components/Dashboard";
import VehicleProfile from "@/components/VehicleProfile";
import DiagnosticHistory from "@/components/DiagnosticHistory";
import NotFound from "@/pages/not-found";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

function Home() {
  return (
    <div className="min-h-screen bg-background">
      <Hero />
      <div className="container mx-auto px-4 py-16 space-y-12">
        <div className="text-center space-y-4">
          <h2 className="text-3xl font-bold" data-testid="text-features-title">
            Professional Diagnostic Features
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto" data-testid="text-features-description">
            Experience the complete AutoSense Diagnostics platform with real-time data, comprehensive vehicle profiles, and detailed diagnostic history.
          </p>
        </div>

        <Tabs defaultValue="dashboard" className="w-full">
          <TabsList className="grid w-full grid-cols-1 sm:grid-cols-3 gap-1 h-auto p-1" data-testid="tabs-main">
            <TabsTrigger value="dashboard" className="text-xs sm:text-sm px-2 py-3.5 min-h-11" data-testid="tab-dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="vehicles" className="text-xs sm:text-sm px-2 py-3.5 min-h-11" data-testid="tab-vehicles">Vehicle Profiles</TabsTrigger>
            <TabsTrigger value="history" className="text-xs sm:text-sm px-2 py-3.5 min-h-11" data-testid="tab-history">Diagnostic History</TabsTrigger>
          </TabsList>
          
          <TabsContent value="dashboard" className="space-y-6" data-testid="content-dashboard">
            <Dashboard vehicleCount={24} activeUsers={8} totalDiagnostics={156} />
          </TabsContent>
          
          <TabsContent value="vehicles" className="space-y-6" data-testid="content-vehicles">
            <div className="grid gap-6 md:grid-cols-2">
              <VehicleProfile 
                make="Toyota"
                model="Camry" 
                year={2020}
                vin="1HGBH41JXMN109186"
                mileage={45240}
                healthStatus="good"
              />
              <VehicleProfile 
                make="Honda"
                model="Accord" 
                year={2019}
                vin="1HGCV1F30JA012345"
                mileage={32150}
                healthStatus="warning"
              />
              <VehicleProfile 
                make="Ford"
                model="F-150" 
                year={2021}
                vin="1FTFW1E53MFA67890"
                mileage={18750}
                healthStatus="critical"
              />
            </div>
          </TabsContent>
          
          <TabsContent value="history" className="space-y-6" data-testid="content-history">
            <DiagnosticHistory />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

function Router() {
  const [currentUser] = useState({
    role: "technician" as const,
    name: "Lerato Lovers",
    email: "lerato.lovers@autosense.co.ls",
    department: "Vehicle Diagnostics",
    employeeId: "AS-TECH-2024-001",
    certifications: ["ASE Master Technician", "OBD-II Specialist", "Hybrid Vehicle Certified"]
  });

  return (
    <div className="min-h-screen bg-background">
      <Header 
        userRole={currentUser.role} 
        userName={currentUser.name}
        userEmail={currentUser.email}
        userDepartment={currentUser.department}
        userEmployeeId={currentUser.employeeId}
        userCertifications={currentUser.certifications}
      />
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Router />
          <Toaster />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
