import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Activity, Shield, Zap } from "lucide-react";
import heroImage from "@assets/generated_images/Automotive_diagnostic_equipment_garage_68927808.png";

export default function Hero() {
  return (
    <section className="relative bg-gradient-to-br from-primary/5 via-background to-primary/10">
      <div className="container mx-auto px-4 py-16 lg:py-24">
        <div className="grid gap-8 lg:grid-cols-2 lg:gap-16 items-center">
          <div className="space-y-6">
            <div className="space-y-4">
              <h1 className="text-4xl font-bold tracking-tight text-foreground lg:text-5xl" data-testid="text-hero-title">
                Professional Vehicle Diagnostics Platform
              </h1>
              <p className="text-xl text-muted-foreground max-w-lg" data-testid="text-hero-description">
                Advanced OBD-II diagnostic tools for professional technicians and garage owners. Real-time insights, comprehensive reports, and data-driven maintenance decisions.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-3">
              <Button size="lg" className="text-base" data-testid="button-get-started">
                Get Started
              </Button>
              <Button variant="outline" size="lg" className="text-base" data-testid="button-learn-more">
                Learn More
              </Button>
            </div>
            
            <div className="grid grid-cols-3 gap-4 pt-4">
              <Card className="p-4 text-center hover-elevate">
                <Activity className="h-6 w-6 mx-auto mb-2 text-chart-2" />
                <p className="text-sm font-medium" data-testid="text-feature-realtime">Real-time Data</p>
              </Card>
              <Card className="p-4 text-center hover-elevate">
                <Shield className="h-6 w-6 mx-auto mb-2 text-chart-3" />
                <p className="text-sm font-medium" data-testid="text-feature-secure">Secure Platform</p>
              </Card>
              <Card className="p-4 text-center hover-elevate">
                <Zap className="h-6 w-6 mx-auto mb-2 text-primary" />
                <p className="text-sm font-medium" data-testid="text-feature-fast">Fast Diagnostics</p>
              </Card>
            </div>
          </div>

          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-transparent rounded-lg"></div>
            <img 
              src={heroImage} 
              alt="Professional automotive diagnostic equipment in modern garage" 
              className="w-full h-auto rounded-lg shadow-lg"
              data-testid="img-hero"
            />
          </div>
        </div>
      </div>
    </section>
  );
}