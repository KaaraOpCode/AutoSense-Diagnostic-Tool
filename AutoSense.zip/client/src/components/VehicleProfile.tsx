import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Car, Settings, FileText, AlertTriangle } from "lucide-react";

interface VehicleProfileProps {
  make?: string;
  model?: string;
  year?: number;
  vin?: string;
  mileage?: number;
  lastService?: string;
  nextService?: string;
  healthStatus?: "good" | "warning" | "critical";
}

export default function VehicleProfile({
  make = "Toyota",
  model = "Camry",
  year = 2020,
  vin = "1HGBH41JXMN109186",
  mileage = 45240,
  lastService = "2024-01-05",
  nextService = "2024-04-05",
  healthStatus = "good"
}: VehicleProfileProps) {

  const getStatusBadgeVariant = (status: string): "default" | "secondary" | "destructive" => {
    switch (status) {
      case "critical": return "destructive";
      case "warning": return "secondary";
      default: return "default";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "critical": return <AlertTriangle className="h-4 w-4" />;
      case "warning": return <AlertTriangle className="h-4 w-4" />;
      default: return <Car className="h-4 w-4" />;
    }
  };

  return (
    <Card className="w-full max-w-2xl" data-testid="card-vehicle-profile">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Car className="h-6 w-6 text-primary" />
            <div>
              <CardTitle data-testid="text-vehicle-name">{year} {make} {model}</CardTitle>
              <CardDescription data-testid="text-vehicle-vin">VIN: {vin}</CardDescription>
            </div>
          </div>
          <Badge variant={getStatusBadgeVariant(healthStatus)} className="flex items-center gap-1" data-testid="badge-health-status">
            {getStatusIcon(healthStatus)}
            {healthStatus}
          </Badge>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Vehicle Details */}
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm font-medium">
              <Settings className="h-4 w-4 text-muted-foreground" />
              Vehicle Details
            </div>
            <div className="grid gap-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Make:</span>
                <span className="font-mono" data-testid="text-make">{make}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Model:</span>
                <span className="font-mono" data-testid="text-model">{model}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Year:</span>
                <span className="font-mono" data-testid="text-year">{year}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Mileage:</span>
                <span className="font-mono" data-testid="text-mileage">{mileage.toLocaleString()} mi</span>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm font-medium">
              <Calendar className="h-4 w-4 text-muted-foreground" />
              Service History
            </div>
            <div className="grid gap-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Last Service:</span>
                <span className="font-mono" data-testid="text-last-service">{lastService}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Next Service:</span>
                <span className="font-mono" data-testid="text-next-service">{nextService}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Service Due:</span>
                <span className="text-chart-3 font-medium" data-testid="text-service-due">In 45 days</span>
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap gap-2 pt-4 border-t">
          <Button variant="default" size="sm" data-testid="button-run-diagnostics">
            <FileText className="h-4 w-4 mr-2" />
            Run Diagnostics
          </Button>
          <Button variant="outline" size="sm" data-testid="button-view-history">
            <Calendar className="h-4 w-4 mr-2" />
            View History
          </Button>
          <Button variant="outline" size="sm" data-testid="button-edit-vehicle">
            <Settings className="h-4 w-4 mr-2" />
            Edit Vehicle
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}