import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Download, Eye, AlertTriangle, CheckCircle, Clock } from "lucide-react";

interface DiagnosticRecord {
  id: string;
  date: string;
  vehicle: string;
  technician: string;
  dtcCount: number;
  severity: "good" | "warning" | "critical";
  status: "completed" | "in-progress" | "pending";
}

interface DiagnosticHistoryProps {
  records?: DiagnosticRecord[];
}

export default function DiagnosticHistory({ records }: DiagnosticHistoryProps) {
  //todo: remove mock functionality - replace with real data from backend
  const defaultRecords: DiagnosticRecord[] = [
    {
      id: "DIAG-001",
      date: "2024-01-15 14:30",
      vehicle: "2020 Toyota Camry",
      technician: "John Smith",
      dtcCount: 2,
      severity: "warning",
      status: "completed"
    },
    {
      id: "DIAG-002", 
      date: "2024-01-15 13:45",
      vehicle: "2019 Honda Accord",
      technician: "Sarah Johnson", 
      dtcCount: 0,
      severity: "good",
      status: "completed"
    },
    {
      id: "DIAG-003",
      date: "2024-01-15 12:15", 
      vehicle: "2021 Ford F-150",
      technician: "Mike Wilson",
      dtcCount: 5,
      severity: "critical",
      status: "in-progress"
    },
    {
      id: "DIAG-004",
      date: "2024-01-15 11:30",
      vehicle: "2018 Chevrolet Malibu", 
      technician: "Lisa Brown",
      dtcCount: 1,
      severity: "warning",
      status: "completed"
    }
  ];

  const diagnosticRecords = records || defaultRecords;

  const getSeverityBadgeVariant = (severity: string): "default" | "secondary" | "destructive" => {
    switch (severity) {
      case "critical": return "destructive";
      case "warning": return "secondary";
      default: return "default";
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case "critical": return <AlertTriangle className="h-3 w-3" />;
      case "warning": return <Clock className="h-3 w-3" />;
      default: return <CheckCircle className="h-3 w-3" />;
    }
  };

  const getStatusBadgeVariant = (status: string): "default" | "secondary" | "outline" => {
    switch (status) {
      case "completed": return "default";
      case "in-progress": return "secondary";
      default: return "outline";
    }
  };

  return (
    <Card className="w-full" data-testid="card-diagnostic-history">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Diagnostic History</CardTitle>
            <CardDescription>Recent vehicle diagnostic sessions and results</CardDescription>
          </div>
          <Button variant="outline" size="sm" data-testid="button-export-history">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </CardHeader>
      
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead data-testid="header-date">Date</TableHead>
              <TableHead data-testid="header-vehicle">Vehicle</TableHead>
              <TableHead data-testid="header-technician">Technician</TableHead>
              <TableHead data-testid="header-dtc-count">DTCs</TableHead>
              <TableHead data-testid="header-severity">Severity</TableHead>
              <TableHead data-testid="header-status">Status</TableHead>
              <TableHead data-testid="header-actions">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {diagnosticRecords.map((record) => (
              <TableRow key={record.id} data-testid={`row-${record.id}`}>
                <TableCell className="font-mono text-sm" data-testid={`text-date-${record.id}`}>
                  {record.date}
                </TableCell>
                <TableCell className="font-medium" data-testid={`text-vehicle-${record.id}`}>
                  {record.vehicle}
                </TableCell>
                <TableCell data-testid={`text-technician-${record.id}`}>
                  {record.technician}
                </TableCell>
                <TableCell data-testid={`text-dtc-count-${record.id}`}>
                  <span className="font-mono">{record.dtcCount}</span>
                </TableCell>
                <TableCell>
                  <Badge 
                    variant={getSeverityBadgeVariant(record.severity)} 
                    className="flex items-center gap-1 w-fit"
                    data-testid={`badge-severity-${record.id}`}
                  >
                    {getSeverityIcon(record.severity)}
                    {record.severity}
                  </Badge>
                </TableCell>
                <TableCell>
                  <Badge 
                    variant={getStatusBadgeVariant(record.status)}
                    data-testid={`badge-status-${record.id}`}
                  >
                    {record.status}
                  </Badge>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Button 
                      variant="ghost" 
                      size="sm"
                      data-testid={`button-view-${record.id}`}
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                    {record.status === "completed" && (
                      <Button 
                        variant="ghost" 
                        size="sm"
                        data-testid={`button-download-${record.id}`}
                      >
                        <Download className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}