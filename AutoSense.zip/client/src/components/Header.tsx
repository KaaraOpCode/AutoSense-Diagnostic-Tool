import { 
  Moon, 
  Sun, 
  Settings, 
  User, 
  Car, 
  Bell, 
  Search, 
  Home, 
  BarChart3, 
  History, 
  Wrench,
  LogOut,
  HelpCircle,
  Menu,
  X
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useTheme } from "@/hooks/use-theme";
import { useLocation, Link } from "wouter";
import { useState } from "react";

interface HeaderProps {
  userRole?: "owner" | "technician" | "admin";
  userName?: string;
  userEmail?: string;
  userDepartment?: string;
  userEmployeeId?: string;
  userCertifications?: string[];
}

export default function Header({ 
  userRole = "technician", 
  userName = "John Doe",
  userEmail = "john.doe@autosense.co.ls",
  userDepartment = "Vehicle Diagnostics",
  userEmployeeId = "AS-TECH-DEFAULT",
  userCertifications = ["OBD-II Certified"]
}: HeaderProps) {
  const { theme, setTheme } = useTheme();
  const [searchQuery, setSearchQuery] = useState("");
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const getRoleBadgeVariant = (role: string) => {
    switch (role) {
      case "admin": return "destructive";
      case "owner": return "default";
      case "technician": return "secondary";
      default: return "secondary";
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Search triggered:", searchQuery);
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur-sm shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between gap-6">
          {/* Brand Section */}
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-3">
              <div className="relative">
                <Car className="h-9 w-9 text-primary" data-testid="icon-logo" />
                <div className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-chart-2 animate-pulse"></div>
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground tracking-tight" data-testid="text-app-title">
                  AutoSense
                </h1>
                <p className="text-xs text-muted-foreground font-medium" data-testid="text-app-subtitle">
                  Diagnostics Platform
                </p>
              </div>
            </div>

            {/* Navigation Menu */}
            <nav className="hidden lg:block">
              <div className="flex items-center gap-1">
                <Button 
                  variant={location === "/" ? "secondary" : "ghost"} 
                  size="sm" 
                  className="gap-2"
                  asChild
                  data-testid="nav-dashboard"
                >
                  <Link href="/">
                    <Home className="h-4 w-4" />
                    Dashboard
                  </Link>
                </Button>
                <Button 
                  variant={location === "/analytics" ? "secondary" : "ghost"} 
                  size="sm" 
                  className="gap-2"
                  asChild
                  data-testid="nav-analytics"
                >
                  <Link href="/analytics">
                    <BarChart3 className="h-4 w-4" />
                    Analytics
                  </Link>
                </Button>
                <Button 
                  variant={location === "/vehicles" ? "secondary" : "ghost"} 
                  size="sm" 
                  className="gap-2"
                  asChild
                  data-testid="nav-vehicles"
                >
                  <Link href="/vehicles">
                    <Wrench className="h-4 w-4" />
                    Vehicles
                  </Link>
                </Button>
              </div>
            </nav>
          </div>

          {/* Mobile Navigation */}
          <div className="lg:hidden">
            <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" aria-label="Open mobile menu" data-testid="button-mobile-menu">
                  <Menu className="h-4 w-4" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-72">
                <SheetHeader className="text-left">
                  <SheetTitle className="flex items-center gap-2">
                    <Car className="h-5 w-5 text-primary" />
                    AutoSense
                  </SheetTitle>
                  <SheetDescription>
                    Professional Vehicle Diagnostics Platform
                  </SheetDescription>
                </SheetHeader>
                
                <div className="mt-8 space-y-4">
                  <div className="space-y-2">
                    <Button 
                      variant={location === "/" ? "secondary" : "ghost"} 
                      className="w-full justify-start gap-3" 
                      asChild
                      onClick={() => setMobileMenuOpen(false)}
                      data-testid="mobile-nav-dashboard"
                    >
                      <Link href="/">
                        <Home className="h-4 w-4" />
                        Dashboard
                      </Link>
                    </Button>
                    <Button 
                      variant={location === "/analytics" ? "secondary" : "ghost"} 
                      className="w-full justify-start gap-3" 
                      asChild
                      onClick={() => setMobileMenuOpen(false)}
                      data-testid="mobile-nav-analytics"
                    >
                      <Link href="/analytics">
                        <BarChart3 className="h-4 w-4" />
                        Analytics
                      </Link>
                    </Button>
                    <Button 
                      variant={location === "/vehicles" ? "secondary" : "ghost"} 
                      className="w-full justify-start gap-3" 
                      asChild
                      onClick={() => setMobileMenuOpen(false)}
                      data-testid="mobile-nav-vehicles"
                    >
                      <Link href="/vehicles">
                        <Wrench className="h-4 w-4" />
                        Vehicles
                      </Link>
                    </Button>
                  </div>
                  
                  <div className="pt-4 border-t">
                    <form onSubmit={handleSearch}>
                      <div className="relative">
                        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                        <Input
                          type="search"
                          placeholder="Search vehicles, DTCs..."
                          className="pl-10"
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          data-testid="mobile-input-search"
                        />
                      </div>
                    </form>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>

          {/* Search and Actions */}
          <div className="flex items-center gap-3">
            {/* Search */}
            <form onSubmit={handleSearch} className="hidden md:block">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search vehicles, DTCs..."
                  className="pl-10 w-64"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  data-testid="input-search"
                />
              </div>
            </form>

            {/* Notifications */}
            <Button 
              variant="ghost" 
              size="icon" 
              className="relative" 
              aria-label="View notifications"
              data-testid="button-notifications"
            >
              <Bell className="h-4 w-4" />
              <span className="absolute -top-1 -right-1 h-2 w-2 rounded-full bg-destructive animate-pulse"></span>
            </Button>

            {/* Theme Toggle */}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
              data-testid="button-theme-toggle"
            >
              {theme === "dark" ? (
                <Sun className="h-4 w-4" />
              ) : (
                <Moon className="h-4 w-4" />
              )}
            </Button>

            {/* User Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-9 w-9 rounded-full hover-elevate" data-testid="button-user-menu">
                  <Avatar className="h-9 w-9">
                    <AvatarImage src="" alt={userName} />
                    <AvatarFallback className="bg-primary text-primary-foreground text-sm font-semibold">
                      {userName.split(" ").map(n => n[0]).join("")}
                    </AvatarFallback>
                  </Avatar>
                  <span className="absolute -bottom-1 -right-1 h-3 w-3 rounded-full bg-chart-2 border-2 border-background"></span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-64" align="end" sideOffset={4}>
                <DropdownMenuLabel className="font-normal p-4">
                  <div className="flex items-center gap-3">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src="" alt={userName} />
                      <AvatarFallback className="bg-primary text-primary-foreground">
                        {userName.split(" ").map(n => n[0]).join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div className="space-y-1 flex-1">
                      <p className="text-sm font-medium" data-testid="text-user-name">{userName}</p>
                      <p className="text-xs text-muted-foreground" data-testid="text-user-email">{userEmail}</p>
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge variant={getRoleBadgeVariant(userRole)} className="text-xs" data-testid="badge-user-role">
                          {userRole}
                        </Badge>
                        <Badge variant="outline" className="text-xs" data-testid="badge-user-employee-id">
                          {userEmployeeId}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground" data-testid="text-user-department">{userDepartment}</p>
                    </div>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <div className="px-4 py-2">
                  <p className="text-xs font-medium text-muted-foreground mb-2" data-testid="text-certifications-label">Certifications</p>
                  <div className="flex flex-wrap gap-1">
                    {userCertifications.map((cert, index) => (
                      <Badge key={index} variant="secondary" className="text-xs" data-testid={`badge-certification-${index}`}>
                        {cert}
                      </Badge>
                    ))}
                  </div>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuGroup>
                  <DropdownMenuItem data-testid="menuitem-profile">
                    <User className="mr-3 h-4 w-4" />
                    My Profile
                  </DropdownMenuItem>
                  <DropdownMenuItem data-testid="menuitem-history">
                    <History className="mr-3 h-4 w-4" />
                    My Sessions
                  </DropdownMenuItem>
                  <DropdownMenuItem data-testid="menuitem-settings">
                    <Settings className="mr-3 h-4 w-4" />
                    Settings
                  </DropdownMenuItem>
                </DropdownMenuGroup>
                <DropdownMenuSeparator />
                <DropdownMenuGroup>
                  <DropdownMenuItem data-testid="menuitem-help">
                    <HelpCircle className="mr-3 h-4 w-4" />
                    Help & Support
                  </DropdownMenuItem>
                  <DropdownMenuItem className="text-destructive focus:text-destructive" data-testid="menuitem-logout">
                    <LogOut className="mr-3 h-4 w-4" />
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuGroup>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </header>
  );
}