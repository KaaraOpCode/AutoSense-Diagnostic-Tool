import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Activity, AlertTriangle, CheckCircle, Clock, Thermometer, Gauge, Zap } from "lucide-react";

interface DashboardProps {
  vehicleCount?: number;
  activeUsers?: number;
  totalDiagnostics?: number;
}

export default function Dashboard({ vehicleCount = 24, activeUsers = 8, totalDiagnostics = 156 }: DashboardProps) {
  //todo: remove mock functionality - replace with real data from backend
  const diagnosticData = [
    { id: "DTC001", code: "P0171", description: "System Too Lean (Bank 1)", severity: "warning", timestamp: "2024-01-15 14:30" },
    { id: "DTC002", code: "P0300", description: "Random/Multiple Cylinder Misfire", severity: "critical", timestamp: "2024-01-15 13:45" },
    { id: "DTC003", code: "P0420", description: "Catalyst System Efficiency Below Threshold", severity: "moderate", timestamp: "2024-01-15 12:15" },
  ];

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case "critical": return <AlertTriangle className="h-4 w-4" />;
      case "warning": return <Clock className="h-4 w-4" />;
      default: return <CheckCircle className="h-4 w-4" />;
    }
  };

  const getSeverityVariant = (severity: string): "destructive" | "secondary" | "default" => {
    switch (severity) {
      case "critical": return "destructive";
      case "warning": return "secondary";
      default: return "default";
    }
  };

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card data-testid="card-vehicle-count">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Vehicles</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="text-vehicle-count">{vehicleCount}</div>
            <p className="text-xs text-muted-foreground">+2 from yesterday</p>
          </CardContent>
        </Card>

        <Card data-testid="card-active-users">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Technicians</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="text-active-users">{activeUsers}</div>
            <p className="text-xs text-muted-foreground">Currently online</p>
          </CardContent>
        </Card>

        <Card data-testid="card-total-diagnostics">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Diagnostics</CardTitle>
            <Gauge className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="text-total-diagnostics">{totalDiagnostics}</div>
            <p className="text-xs text-muted-foreground">This month</p>
          </CardContent>
        </Card>
      </div>

      {/* Real-time Sensor Data */}
      <Card data-testid="card-sensor-data">
        <CardHeader>
          <CardTitle>Real-time Sensor Data</CardTitle>
          <CardDescription>Current vehicle diagnostic readings</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Thermometer className="h-4 w-4 text-chart-3" />
                <span className="text-sm font-medium">Engine Temp</span>
              </div>
              <div className="text-2xl font-bold font-mono" data-testid="text-engine-temp">89°C</div>
              <Progress value={65} className="h-2" />
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Gauge className="h-4 w-4 text-primary" />
                <span className="text-sm font-medium">RPM</span>
              </div>
              <div className="text-2xl font-bold font-mono" data-testid="text-rpm">2,150</div>
              <Progress value={35} className="h-2" />
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Zap className="h-4 w-4 text-chart-2" />
                <span className="text-sm font-medium">Battery</span>
              </div>
              <div className="text-2xl font-bold font-mono" data-testid="text-battery">12.4V</div>
              <Progress value={85} className="h-2" />
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Activity className="h-4 w-4 text-chart-1" />
                <span className="text-sm font-medium">Load</span>
              </div>
              <div className="text-2xl font-bold font-mono" data-testid="text-load">42%</div>
              <Progress value={42} className="h-2" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recent Diagnostic Codes */}
      <Card data-testid="card-recent-dtcs">
        <CardHeader>
          <CardTitle>Recent Diagnostic Codes</CardTitle>
          <CardDescription>Latest DTCs detected across all vehicles</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {diagnosticData.map((diagnostic) => (
              <div key={diagnostic.id} className="flex items-center justify-between p-3 border rounded-lg" data-testid={`dtc-${diagnostic.id}`}>
                <div className="flex items-center gap-3">
                  <div className="text-chart-4">{getSeverityIcon(diagnostic.severity)}</div>
                  <div>
                    <p className="font-mono text-sm font-medium" data-testid={`text-dtc-code-${diagnostic.id}`}>{diagnostic.code}</p>
                    <p className="text-sm text-muted-foreground" data-testid={`text-dtc-description-${diagnostic.id}`}>{diagnostic.description}</p>
                  </div>
                </div>
                <div className="text-right">
                  <Badge variant={getSeverityVariant(diagnostic.severity)} data-testid={`badge-severity-${diagnostic.id}`}>
                    {diagnostic.severity}
                  </Badge>
                  <p className="text-xs text-muted-foreground mt-1" data-testid={`text-timestamp-${diagnostic.id}`}>
                    {diagnostic.timestamp}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}